import React, { useState, useEffect, useRef } from 'react';
import { PLACES } from '../constants';
import PlaceCard from './PlaceCard';
import { Place } from '../types';
import { Search, Map as MapIcon, List, SlidersHorizontal } from 'lucide-react';

// Declare Leaflet global
declare global {
  interface Window {
    L: any;
  }
}

interface Props {
  isPremium: boolean;
}

const InteractiveMap: React.FC<Props> = ({ isPremium }) => {
  const [filter, setFilter] = useState<'all' | 'restaurant' | 'culture' | 'activity' | 'shop'>('all');
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'map' | 'list'>('list'); // For mobile
  const [selectedPlaceId, setSelectedPlaceId] = useState<string | null>(null);
  
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markersRef = useRef<{ [key: string]: any }>({});

  const filteredPlaces = PLACES.filter(place => {
    const matchesType = filter === 'all' || place.type === filter;
    const matchesSearch = place.name.toLowerCase().includes(search.toLowerCase()) || 
                          place.description.toLowerCase().includes(search.toLowerCase());
    return matchesType && matchesSearch;
  });

  // Initialize Map
  useEffect(() => {
    if (mapRef.current && !mapInstance.current && window.L) {
      const L = window.L;
      
      const map = L.map(mapRef.current, {
        zoomControl: false 
      }).setView([39.4753, -0.3755], 14);
      
      L.control.zoom({
        position: 'bottomright'
      }).addTo(map);
      
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 20
      }).addTo(map);

      mapInstance.current = map;
    }

    return () => {
      if (mapInstance.current) {
        mapInstance.current.remove();
        mapInstance.current = null;
      }
    };
  }, []);

  // Update Markers
  useEffect(() => {
    if (!mapInstance.current || !window.L) return;
    const L = window.L;
    const map = mapInstance.current;

    Object.values(markersRef.current).forEach((marker: any) => marker.remove());
    markersRef.current = {};

    filteredPlaces.forEach(place => {
      let color = '#6b7280';
      if (place.type === 'restaurant') color = '#f97316'; // orange
      else if (place.type === 'culture') color = '#3b82f6'; // blue
      else if (place.type === 'activity') color = '#10b981'; // green
      else if (place.type === 'shop') color = '#f59e0b'; // yellow

      const icon = L.divIcon({
        className: 'custom-div-icon',
        html: `
          <div style="
            background-color: ${color}; 
            width: 16px; 
            height: 16px; 
            border-radius: 50%; 
            border: 3px solid white; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
            transition: all 0.2s ease;
          "></div>
        `,
        iconSize: [16, 16],
        iconAnchor: [8, 8],
        popupAnchor: [0, -10]
      });

      const marker = L.marker([place.coordinates.lat, place.coordinates.lng], { icon })
        .addTo(map);

      // Using inline styles for popup to ensure reliability without extra CSS files
      const popupContent = `
        <div style="font-family: 'Outfit', sans-serif; width: 220px; overflow: hidden; border-radius: 12px;">
          <div style="
            height: 110px; 
            width: 100%; 
            background-image: url('${place.imageUrl}'); 
            background-size: cover; 
            background-position: center;
            background-color: #e5e7eb;
          ">
          </div>
          <div style="padding: 12px;">
            <h3 style="font-weight: 800; color: #111827; font-size: 14px; margin: 0 0 4px 0; line-height: 1.3;">${place.name}</h3>
            <p style="font-size: 11px; color: #6B7280; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin: 0;">${place.type}</p>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent, {
        closeButton: false,
        className: 'custom-map-popup shadow-xl rounded-2xl border-0',
        maxWidth: 240,
        minWidth: 220
      });
      
      marker.on('click', () => {
        setSelectedPlaceId(place.id);
        const card = document.getElementById(`place-card-${place.id}`);
        if (card) {
          card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      });

      markersRef.current[place.id] = marker;
    });

  }, [filteredPlaces]);

  const handleCardClick = (place: Place) => {
    setSelectedPlaceId(place.id);
    if (mapInstance.current && window.L) {
      mapInstance.current.setView([place.coordinates.lat, place.coordinates.lng], 16);
      const marker = markersRef.current[place.id];
      if (marker) {
        marker.openPopup();
      }
      
      if (window.innerWidth < 768) {
        setViewMode('map');
      }
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)]">
      {/* Header & Controls */}
      <div className="bg-white/90 backdrop-blur-md border-b border-white/40 p-4 shadow-sm z-20 flex-shrink-0">
        <div className="max-w-7xl mx-auto w-full">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            
            <div className="flex w-full md:w-auto gap-3 items-center">
              <div className="relative flex-grow md:w-72 group">
                <input
                  type="text"
                  placeholder="Zoek tapas, musea..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-gray-100/50 border border-gray-200 rounded-full focus:ring-2 focus:ring-orange-400 focus:bg-white focus:outline-none transition-all"
                />
                <Search className="absolute left-4 top-3.5 text-gray-400 group-focus-within:text-orange-500 transition-colors" size={18} />
              </div>
              
              <div className="flex md:hidden bg-gray-100 rounded-full p-1">
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2.5 rounded-full transition-all ${viewMode === 'list' ? 'bg-white shadow text-orange-600' : 'text-gray-400'}`}
                >
                  <List size={20} />
                </button>
                <button
                  onClick={() => setViewMode('map')}
                  className={`p-2.5 rounded-full transition-all ${viewMode === 'map' ? 'bg-white shadow text-orange-600' : 'text-gray-400'}`}
                >
                  <MapIcon size={20} />
                </button>
              </div>
            </div>

            <div className="flex space-x-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-hide py-1">
              {['all', 'restaurant', 'culture', 'activity', 'shop'].map((t) => (
                <button
                  key={t}
                  onClick={() => setFilter(t as any)}
                  className={`px-5 py-2.5 rounded-full text-sm font-bold capitalize whitespace-nowrap transition-all transform hover:scale-105 ${
                    filter === t
                      ? 'bg-gradient-to-r from-orange-400 to-pink-500 text-white shadow-lg shadow-orange-500/30'
                      : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {t === 'all' ? 'Alles' : t}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Content Area - Split View */}
      <div className="flex-grow flex overflow-hidden relative">
        
        {/* List View */}
        <div className={`
          w-full md:w-1/2 lg:w-2/5 p-4 md:p-6 overflow-y-auto transition-all duration-300 bg-gray-50/50
          ${viewMode === 'map' ? 'hidden md:block' : 'block'}
        `}>
          <div className="space-y-6 max-w-2xl mx-auto pb-20">
            <div className="flex justify-between items-center px-2">
                <p className="text-gray-500 font-medium text-sm">
                {filteredPlaces.length} hotspots gevonden
                </p>
                <div className="flex items-center text-xs text-orange-500 font-bold bg-orange-50 px-3 py-1 rounded-full border border-orange-100">
                    <SlidersHorizontal size={12} className="mr-1" />
                    Filters actief
                </div>
            </div>
            
            {filteredPlaces.map((place) => (
              <div 
                key={place.id} 
                id={`place-card-${place.id}`}
                onClick={() => handleCardClick(place)}
                className={`cursor-pointer transition-all duration-300 ${selectedPlaceId === place.id ? 'ring-4 ring-orange-200 rounded-3xl transform scale-[1.01]' : 'hover:opacity-95'}`}
              >
                <PlaceCard place={place} isPremium={isPremium} />
              </div>
            ))}
            {filteredPlaces.length === 0 && (
              <div className="text-center py-20 text-gray-400">
                <div className="bg-white p-6 rounded-full inline-block shadow-sm mb-4">
                     <Search size={48} className="text-orange-200" />
                </div>
                <h3 className="text-xl font-bold text-gray-600">Geen hotspots gevonden</h3>
                <p className="mt-2">Probeer een andere zoekterm of filter.</p>
              </div>
            )}
          </div>
        </div>

        {/* Map View */}
        <div className={`
          w-full md:w-1/2 lg:w-3/5 relative h-full
          ${viewMode === 'list' ? 'hidden md:block' : 'block'}
        `}>
           <div id="map" ref={mapRef} className="w-full h-full z-0 outline-none" style={{borderRadius: window.innerWidth >= 768 ? '24px 0 0 24px' : '0'}} />
           
           <button 
             onClick={() => setViewMode('list')}
             className="md:hidden absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-white text-gray-900 px-6 py-3 rounded-full shadow-xl font-bold flex items-center gap-2 z-[400] border border-gray-100 active:scale-95 transition-transform"
           >
             <List size={18} /> Bekijk Lijst
           </button>
        </div>
      </div>
    </div>
  );
};

export default InteractiveMap;