import React, { useState, useEffect, useRef } from 'react';
import { generateQuiz, generateAudioGuide } from '../services/geminiService';
import { QuizQuestion } from '../types';
import { Headphones, Trophy, Play, Pause, Lock, CheckCircle, XCircle, AlertCircle, Map, Loader2, Volume2, SkipForward, Landmark, Umbrella, Utensils, Mic, Flower } from 'lucide-react';

interface Props {
  isPremium: boolean;
  triggerUpgrade: () => void;
}

// --- Audio Decoding Utilities ---
function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      // Convert PCM 16-bit to Float32 (-1.0 to 1.0)
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const DEMO_LOCATIONS = [
  { name: 'Plaza de la Virgen', icon: <Landmark size={14}/>, color: 'bg-blue-100 text-blue-700' },
  { name: 'Mercado Central', icon: <Utensils size={14}/>, color: 'bg-orange-100 text-orange-700' },
  { name: 'Torres de Serranos', icon: <Landmark size={14}/>, color: 'bg-stone-100 text-stone-700' },
  { name: 'Ciudad de las Artes', icon: <Landmark size={14}/>, color: 'bg-cyan-100 text-cyan-700' },
  { name: 'Playa Malvarrosa', icon: <Umbrella size={14}/>, color: 'bg-yellow-100 text-yellow-700' },
  { name: 'Bioparc', icon: <Map size={14}/>, color: 'bg-green-100 text-green-700' },
  { name: 'Estadio Mestalla', icon: <Trophy size={14}/>, color: 'bg-gray-100 text-gray-700' },
  { name: 'Albufera Park', icon: <Map size={14}/>, color: 'bg-teal-100 text-teal-700' },
  { name: 'Jardín Botánico', icon: <Flower size={14}/>, color: 'bg-emerald-100 text-emerald-700' },
];

const AudioTour: React.FC<{ isPremium: boolean; triggerUpgrade: () => void }> = ({ isPremium, triggerUpgrade }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<string | null>(null);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const startTimeRef = useRef<number>(0);
  const pausedAtRef = useRef<number>(0);
  const animationFrameRef = useRef<number>(0);

  // Initialize AudioContext
  useEffect(() => {
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
      cancelAnimationFrame(animationFrameRef.current);
    };
  }, []);

  const updateProgress = () => {
    if (!audioContextRef.current || !startTimeRef.current || !audioBufferRef.current) return;
    
    const elapsed = audioContextRef.current.currentTime - startTimeRef.current;
    const totalDuration = audioBufferRef.current.duration;
    
    if (elapsed >= totalDuration) {
      setProgress(100);
      setCurrentTime(totalDuration);
      setIsPlaying(false);
      pausedAtRef.current = 0;
      return;
    }

    setCurrentTime(elapsed);
    setProgress((elapsed / totalDuration) * 100);
    animationFrameRef.current = requestAnimationFrame(updateProgress);
  };

  const stopAudio = () => {
    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.stop();
      } catch (e) {
        // Ignore error if already stopped
      }
      sourceNodeRef.current = null;
    }
    cancelAnimationFrame(animationFrameRef.current);
    setIsPlaying(false);
    pausedAtRef.current = 0;
    setProgress(0);
    setCurrentTime(0);
  };

  const playBuffer = (buffer: AudioBuffer, offset: number = 0) => {
    if (!audioContextRef.current) return;

    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    source.start(0, offset);
    
    source.onended = () => {
       // Only reset if we didn't pause manually (handled by state check in updateProgress usually)
    };

    sourceNodeRef.current = source;
    startTimeRef.current = audioContextRef.current.currentTime - offset;
    setDuration(buffer.duration);
    setIsPlaying(true);
    
    cancelAnimationFrame(animationFrameRef.current);
    updateProgress();
  };

  const togglePlayback = () => {
     if (!audioContextRef.current || !audioBufferRef.current) return;

     if (isPlaying) {
        if (sourceNodeRef.current) {
            sourceNodeRef.current.stop();
            sourceNodeRef.current = null;
        }
        cancelAnimationFrame(animationFrameRef.current);
        pausedAtRef.current = audioContextRef.current.currentTime - startTimeRef.current;
        setIsPlaying(false);
     } else {
        playBuffer(audioBufferRef.current, pausedAtRef.current);
     }
  };

  const simulateArrival = async (loc: string) => {
    if (!isPremium) {
      triggerUpgrade();
      return;
    }

    // Stop existing audio
    stopAudio();
    setCurrentLocation(loc);
    setIsLoadingAudio(true);
    audioBufferRef.current = null;
    setDuration(0);

    try {
      // 1. Generate audio via Gemini
      const base64Audio = await generateAudioGuide(loc);
      
      if (!base64Audio) {
        throw new Error("No audio generated");
      }

      // 2. Setup Audio Context
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      } else if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }

      // 3. Decode PCM Data
      const rawBytes = decodeBase64(base64Audio);
      const buffer = await decodeAudioData(rawBytes, audioContextRef.current, 24000, 1);
      
      audioBufferRef.current = buffer;

      // 4. Play
      playBuffer(buffer);

    } catch (error) {
      console.error("Failed to play audio tour", error);
      alert("De stem kon niet worden gegenereerd. Probeer het opnieuw.");
    } finally {
      setIsLoadingAudio(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="group relative rounded-[2.5rem] overflow-hidden shadow-2xl shadow-indigo-500/10 mb-12 transition-transform hover:scale-[1.01] duration-500">
      {/* Background Image */}
      <div className="absolute inset-0 bg-indigo-900">
        <img 
          src="https://images.unsplash.com/photo-1596541663957-3075670868a6?auto=format&fit=crop&w=1200&q=80" 
          alt="Walking Tour" 
          className="w-full h-full object-cover opacity-60 transition-transform duration-1000 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/90 via-indigo-900/70 to-purple-900/40"></div>
      </div>

      <div className="relative z-10 p-8 md:p-12 grid md:grid-cols-2 gap-10 items-start">
        <div className="h-full flex flex-col justify-center">
          <div className="flex items-center mb-6">
            <div className="bg-white/10 p-3 rounded-2xl mr-4 backdrop-blur-md shadow-lg border border-white/10 animate-pulse-slow">
                <Headphones className="w-8 h-8 text-pink-300" />
            </div>
            <div>
              <span className="text-pink-300 font-bold uppercase tracking-widest text-xs mb-1 block">GPS Gestuurd</span>
              <h2 className="text-3xl md:text-4xl font-black text-white tracking-tight leading-none">Smart Audio Tour</h2>
            </div>
          </div>
          
          <p className="text-indigo-100 text-lg font-medium leading-relaxed mb-6">
            Wandel door Valencia en laat onze <span className="text-white font-bold">Virtuele Gids (Zephyr)</span> je verhalen vertellen. Selecteer een locatie om de stem te testen.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-6 border border-white/20 shadow-inner flex flex-col h-full">
            <div className="mb-4 flex items-center justify-between">
                <p className="text-[10px] text-indigo-200 uppercase font-extrabold tracking-widest">
                    <Map size={10} className="inline mr-1" />
                    Simuleer Locatie
                </p>
                {isLoadingAudio && (
                   <span className="text-[10px] text-green-300 font-bold flex items-center animate-pulse">
                     <Mic size={10} className="mr-1" /> Stem Genereren...
                   </span>
                )}
            </div>
            
            <div className="grid grid-cols-2 gap-2 mb-6 max-h-48 overflow-y-auto pr-1 scrollbar-hide">
            {DEMO_LOCATIONS.map((loc) => (
                <button
                key={loc.name}
                onClick={() => simulateArrival(loc.name)}
                disabled={isLoadingAudio && currentLocation !== loc.name}
                className={`
                    border border-white/10 rounded-xl px-3 py-2.5 text-xs font-bold transition-all flex items-center justify-start text-left shadow-sm group/btn relative overflow-hidden
                    ${currentLocation === loc.name ? 'bg-white text-indigo-900 ring-2 ring-indigo-300' : 'bg-indigo-950/40 text-white hover:bg-white/20'}
                `}
                >
                    <span className={`p-1.5 rounded-lg mr-2 ${currentLocation === loc.name ? 'bg-indigo-100 text-indigo-600' : 'bg-white/10'}`}>
                        {loc.icon}
                    </span>
                    <span className="truncate">{loc.name}</span>
                    {currentLocation === loc.name && isPlaying && (
                        <span className="absolute right-2 flex space-x-0.5">
                            <span className="w-1 h-3 bg-indigo-500 rounded-full animate-bounce delay-0"></span>
                            <span className="w-1 h-3 bg-indigo-500 rounded-full animate-bounce delay-100"></span>
                            <span className="w-1 h-3 bg-indigo-500 rounded-full animate-bounce delay-200"></span>
                        </span>
                    )}
                </button>
            ))}
            </div>

            {currentLocation && isPremium ? (
            <div className="bg-white/95 backdrop-blur-xl rounded-2xl p-5 shadow-xl animate-fade-in border border-white/50 mt-auto">
                <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center min-w-0">
                        <div className="w-10 h-10 rounded-full bg-indigo-100 flex-shrink-0 flex items-center justify-center mr-3 relative">
                            {isLoadingAudio ? (
                               <Loader2 size={20} className="text-indigo-600 animate-spin" />
                            ) : (
                               <div className="relative">
                                   <Volume2 size={20} className="text-indigo-600" />
                                   {isPlaying && <span className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full border-2 border-white"></span>}
                               </div>
                            )}
                        </div>
                        <div className="min-w-0">
                             <p className="text-indigo-900 font-bold text-sm truncate">{currentLocation}</p>
                             <p className="text-gray-500 text-xs truncate">
                                {isLoadingAudio ? 'Stem Genereren...' : isPlaying ? 'Gids spreekt' : 'Gepauzeerd'}
                             </p>
                        </div>
                    </div>
                    
                    <button 
                        onClick={togglePlayback}
                        disabled={isLoadingAudio}
                        className={`w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center transition-all shadow-md transform hover:scale-105 active:scale-95 ${isLoadingAudio ? 'bg-gray-200 text-gray-400' : 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white'}`}
                    >
                        {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
                    </button>
                </div>
                
                {/* Visual Progress Bar */}
                <div className="flex items-center gap-3 text-[10px] font-medium text-gray-400 tabular-nums">
                    <span>{formatTime(currentTime)}</span>
                    <div className="flex-grow h-1.5 bg-gray-200 rounded-full overflow-hidden relative">
                        <div 
                            className="absolute top-0 left-0 h-full bg-indigo-500 rounded-full transition-all duration-100 ease-linear"
                            style={{ width: `${progress}%` }}
                        ></div>
                    </div>
                    <span>{formatTime(duration)}</span>
                </div>
            </div>
            ) : (
                <div className="mt-auto p-4 rounded-2xl border border-white/10 bg-white/5 text-center text-indigo-200 text-sm">
                    Selecteer een locatie om een demo te starten.
                </div>
            )}
        </div>
      </div>
      
      {!isPremium && (
        <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-md z-20 flex flex-col items-center justify-center text-center p-6">
          <div className="bg-white/10 p-5 rounded-full mb-6 border border-white/20 shadow-2xl">
             <Lock className="w-10 h-10 text-white" />
          </div>
          <h3 className="text-3xl font-black text-white mb-3">Vergrendeld</h3>
          <p className="max-w-md text-gray-200 mb-8 font-medium">Upgrade naar Premium om toegang te krijgen tot locatie-gebaseerde audio gidsen.</p>
          <button onClick={triggerUpgrade} className="bg-white text-gray-900 font-bold py-4 px-10 rounded-full transition-all shadow-xl hover:shadow-2xl hover:bg-gray-50 transform hover:scale-105">
            Ontgrendel Nu
          </button>
        </div>
      )}
    </div>
  );
};

const DailyQuiz: React.FC<{ isPremium: boolean; triggerUpgrade: () => void }> = ({ isPremium, triggerUpgrade }) => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);

  const startQuiz = async () => {
    if (!isPremium) {
      triggerUpgrade();
      return;
    }
    setLoading(true);
    const qs = await generateQuiz();
    setQuestions(qs);
    setCurrentIndex(0);
    setScore(0);
    setShowResult(false);
    setSelectedAnswer(null);
    setLoading(false);
  };

  const handleAnswer = (idx: number) => {
    setSelectedAnswer(idx);
    if (idx === questions[currentIndex].correctAnswer) {
      setScore(s => s + 1);
    }
    setTimeout(() => {
      if (currentIndex < questions.length - 1) {
        setCurrentIndex(prev => prev + 1);
        setSelectedAnswer(null);
      } else {
        setShowResult(true);
      }
    }, 2000);
  };

  return (
    <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl shadow-yellow-500/10 border border-white/50 bg-white mb-20">
      {/* Decorative Header Image */}
      <div className="h-40 relative overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1511690656952-34342d5c2899?auto=format&fit=crop&w=1200&q=80" 
            alt="Social Quiz" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-white via-white/40 to-transparent"></div>
          <div className="absolute bottom-6 left-8 flex items-center">
            <div className="bg-yellow-400 p-3 rounded-2xl mr-4 shadow-lg rotate-3">
                 <Trophy className="w-8 h-8 text-white" />
            </div>
            <div>
                 <span className="block text-yellow-600 font-bold text-xs uppercase tracking-wider mb-1">Dagelijkse Challenge</span>
                 <h2 className="text-3xl font-black text-gray-900">Valencia Quiz</h2>
            </div>
          </div>
      </div>

      <div className="p-8 pt-6">
      {!isPremium ? (
         <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="bg-gray-100 p-5 rounded-full mb-6">
                <Lock className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">Daag je vrienden uit!</h3>
            <p className="text-gray-500 max-w-md mb-8 font-medium">
              Wie kent Valencia het best? Krijg elke dag 3 nieuwe vragen over de stad.
            </p>
            <button onClick={triggerUpgrade} className="text-orange-600 font-bold border-2 border-orange-100 hover:border-orange-500 hover:bg-orange-50 px-8 py-3 rounded-full transition-all">
              Word Premium Lid
            </button>
         </div>
      ) : (
        <>
          {loading ? (
            <div className="py-20 flex justify-center">
              <div className="animate-spin rounded-full h-14 w-14 border-b-4 border-orange-500"></div>
            </div>
          ) : questions.length === 0 ? (
            <div className="text-center py-12">
              <p className="mb-8 text-gray-500 text-lg">Start de quiz van vandaag en test je kennis!</p>
              <button onClick={startQuiz} className="bg-gradient-to-r from-orange-400 to-yellow-500 text-white font-bold py-4 px-12 rounded-2xl hover:shadow-lg hover:shadow-orange-300 transition-all transform hover:-translate-y-1">
                Start Quiz
              </button>
            </div>
          ) : showResult ? (
            <div className="text-center py-12 animate-fade-in bg-gradient-to-br from-yellow-50 to-orange-50 rounded-3xl border border-yellow-100">
              <div className="inline-block p-4 bg-white rounded-full shadow-lg mb-6">
                 <Trophy className="w-16 h-16 text-yellow-500 animate-bounce" />
              </div>
              <h3 className="text-3xl font-black mb-3 text-gray-900">Quiz Voltooid!</h3>
              <p className="text-xl text-gray-600 mb-8">Je score: <span className="font-black text-orange-500 text-3xl ml-2">{score} / {questions.length}</span></p>
              <button onClick={startQuiz} className="text-orange-600 font-bold hover:bg-orange-100 px-6 py-3 rounded-full transition-colors">
                Nog een keer spelen
              </button>
            </div>
          ) : (
            <div className="animate-fade-in max-w-2xl mx-auto">
              <div className="flex justify-between text-sm font-bold mb-6">
                <span className="bg-gray-100 px-3 py-1 rounded-full text-gray-500">Vraag {currentIndex + 1} / {questions.length}</span>
                <span className="text-orange-500 bg-orange-50 px-3 py-1 rounded-full">Score: {score}</span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-8 leading-snug">{questions[currentIndex].question}</h3>
              <div className="space-y-4">
                {questions[currentIndex].options.map((opt, idx) => {
                  let btnClass = "w-full p-5 text-left rounded-2xl border-2 transition-all font-medium text-lg flex justify-between items-center group ";
                  if (selectedAnswer === null) {
                    btnClass += "border-gray-100 hover:border-orange-200 hover:bg-orange-50 text-gray-700 shadow-sm hover:shadow-md";
                  } else if (idx === questions[currentIndex].correctAnswer) {
                    btnClass += "border-green-400 bg-green-50 text-green-800 shadow-none";
                  } else if (idx === selectedAnswer) {
                    btnClass += "border-red-400 bg-red-50 text-red-800 shadow-none";
                  } else {
                    btnClass += "border-transparent bg-gray-50 text-gray-400 opacity-50 shadow-none";
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => selectedAnswer === null && handleAnswer(idx)}
                      disabled={selectedAnswer !== null}
                      className={btnClass}
                    >
                        <span>{opt}</span>
                        {selectedAnswer !== null && idx === questions[currentIndex].correctAnswer && <CheckCircle className="text-green-600" size={24} />}
                        {selectedAnswer === idx && idx !== questions[currentIndex].correctAnswer && <XCircle className="text-red-600" size={24} />}
                        {selectedAnswer === null && <div className="w-5 h-5 rounded-full border-2 border-gray-200 group-hover:border-orange-400"></div>}
                    </button>
                  );
                })}
              </div>
              {selectedAnswer !== null && (
                 <div className="mt-8 p-6 bg-blue-50/80 rounded-2xl border border-blue-100 text-blue-900 flex items-start animate-fade-in">
                    <AlertCircle className="flex-shrink-0 mr-4 mt-0.5 text-blue-500" size={24} />
                    <p className="text-base leading-relaxed">{questions[currentIndex].explanation}</p>
                 </div>
              )}
            </div>
          )}
        </>
      )}
      </div>
    </div>
  );
};

const PremiumFeatures: React.FC<Props> = ({ isPremium, triggerUpgrade }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 md:py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-black text-gray-900 mb-4">Premium <span className="text-orange-500">Beleving</span></h1>
        <p className="text-gray-600 text-xl max-w-2xl mx-auto">Haal alles uit je stedentrip met interactieve tools en exclusieve voordelen.</p>
      </div>
      
      <AudioTour isPremium={isPremium} triggerUpgrade={triggerUpgrade} />
      <DailyQuiz isPremium={isPremium} triggerUpgrade={triggerUpgrade} />
    </div>
  );
};

export default PremiumFeatures;