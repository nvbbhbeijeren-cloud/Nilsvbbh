import React, { useState } from 'react';
import { Place } from '../types';
import { MapPin, Tag, Percent } from 'lucide-react';

interface Props {
  place: Place;
  isPremium: boolean;
}

const PlaceCard: React.FC<Props> = ({ place, isPremium }) => {
  const [imgSrc, setImgSrc] = useState(place.imageUrl);
  const [hasError, setHasError] = useState(false);

  // Fallback image if the source fails
  const handleImageError = () => {
    if (!hasError) {
      setHasError(true);
      // High quality fallback image of Valencia
      setImgSrc('https://images.unsplash.com/photo-1596541663957-3075670868a6?auto=format&fit=crop&w=800&q=80');
    }
  };

  return (
    <div className="bg-white rounded-3xl shadow-lg shadow-gray-100 overflow-hidden hover:shadow-xl hover:shadow-orange-100 transition-all duration-300 border border-gray-100 flex flex-col h-full group hover:-translate-y-1">
      
      {/* Image Container */}
      <div className="relative h-56 w-full overflow-hidden bg-gray-200">
        <img
          src={imgSrc}
          alt={place.name}
          onError={handleImageError}
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60"></div>
        
        {/* Partner Badge - Positioned to not overlap text */}
        {place.isPartner && (
          <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm text-orange-600 text-xs font-bold px-3 py-1.5 rounded-full shadow-lg flex items-center transform group-hover:scale-105 transition-transform z-10 border border-orange-100">
            <Tag size={12} className="mr-1.5" /> Partner
          </div>
        )}
      </div>

      {/* Content Container */}
      <div className="p-6 flex-1 flex flex-col relative">
        <div className="flex justify-between items-start mb-2 gap-2">
          <h3 className="text-xl font-bold text-gray-900 leading-tight group-hover:text-orange-600 transition-colors line-clamp-2">
            {place.name}
          </h3>
        </div>
        
        <div className="flex items-center mb-4">
             <span className={`text-xs font-bold px-2.5 py-1 rounded-full uppercase tracking-wide border ${
                place.type === 'restaurant' ? 'bg-red-50 text-red-600 border-red-100' :
                place.type === 'culture' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                place.type === 'activity' ? 'bg-green-50 text-green-600 border-green-100' :
                'bg-yellow-50 text-yellow-700 border-yellow-100'
            }`}>
                {place.type}
            </span>
        </div>

        <p className="text-gray-600 text-sm mb-5 flex-1 leading-relaxed line-clamp-3">
          {place.description}
        </p>
        
        <div className="flex items-center text-gray-500 text-xs font-medium mb-5 bg-gray-50 p-2.5 rounded-xl w-full border border-gray-100">
          <MapPin size={14} className="mr-2 flex-shrink-0 text-orange-400" />
          <span className="truncate">{place.address}</span>
        </div>

        {/* Discount Section - Fixed height to align cards */}
        {place.isPartner && place.discount ? (
          <div className={`mt-auto p-3 rounded-2xl flex items-center transition-all ${isPremium ? 'bg-gradient-to-r from-orange-50 to-pink-50 border border-orange-100' : 'bg-gray-50 border border-gray-100'}`}>
            <div className={`p-2 rounded-full mr-3 shadow-sm flex-shrink-0 ${isPremium ? 'bg-white text-orange-500' : 'bg-white text-gray-400'}`}>
              <Percent size={18} />
            </div>
            <div className="min-w-0">
              <p className={`text-sm font-bold truncate ${isPremium ? 'text-gray-900' : 'text-gray-500'}`}>
                {isPremium ? place.discount : "Exclusieve deal"}
              </p>
              {!isPremium && <p className="text-[10px] uppercase font-bold text-orange-400 mt-0.5">Upgrade om te zien</p>}
            </div>
          </div>
        ) : (
           <div className="mt-auto h-[62px]"></div> /* Spacer to keep buttons aligned */
        )}
      </div>
    </div>
  );
};

export default PlaceCard;