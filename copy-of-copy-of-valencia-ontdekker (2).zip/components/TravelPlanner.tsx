import React, { useState } from 'react';
import { generateTravelPlan } from '../services/geminiService';
import { DayPlan } from '../types';
import { Calendar, Wand2, Loader2, Clock, MapPin } from 'lucide-react';

const TravelPlanner: React.FC = () => {
  const [days, setDays] = useState(3);
  const [interests, setInterests] = useState('');
  const [plan, setPlan] = useState<DayPlan[]>([]);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!interests.trim()) return;
    setLoading(true);
    const result = await generateTravelPlan(days, interests);
    setPlan(result);
    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 md:py-12">
      <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl shadow-orange-500/20 mb-16 bg-white transform transition-all hover:scale-[1.01] duration-500">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&w=1600&q=80" 
            alt="Travel Planning" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/90 to-blue-800/80 backdrop-blur-[2px]"></div>
        </div>

        <div className="relative z-10 p-8 md:p-14 text-white">
          <div className="inline-flex items-center bg-white/20 backdrop-blur-md rounded-full px-4 py-1.5 text-sm font-bold text-orange-200 mb-6 border border-white/10">
            <Wand2 size={16} className="mr-2" />
            Slim Gepland
          </div>
          
          <h2 className="text-4xl md:text-5xl font-black mb-6 leading-tight">
            Jouw droomreis in <br/> <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-300">één klik</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="bg-white/10 backdrop-blur-md p-2 rounded-2xl border border-white/10">
              <label className="block text-xs font-bold text-blue-200 mb-1 px-2 uppercase tracking-wider">Reisduur</label>
              <select 
                value={days} 
                onChange={(e) => setDays(Number(e.target.value))}
                className="w-full bg-transparent text-white text-xl font-bold p-2 focus:outline-none cursor-pointer option:text-gray-900"
              >
                {[1, 2, 3, 4, 5, 6, 7].map(d => (
                  <option key={d} value={d} className="text-gray-900">{d} Dagen</option>
                ))}
              </select>
            </div>
            <div className="md:col-span-2 bg-white/10 backdrop-blur-md p-2 rounded-2xl border border-white/10">
              <label className="block text-xs font-bold text-blue-200 mb-1 px-2 uppercase tracking-wider">Wat vind je leuk?</label>
              <input 
                type="text" 
                value={interests}
                onChange={(e) => setInterests(e.target.value)}
                placeholder="Bijv. Moderne kunst, paella eten, fietsen..."
                className="w-full bg-transparent text-white text-xl font-medium p-2 placeholder-blue-300/50 focus:outline-none"
              />
            </div>
          </div>
          
          <button 
            onClick={handleGenerate}
            disabled={loading || !interests}
            className="w-full bg-gradient-to-r from-orange-500 to-pink-600 hover:from-orange-400 hover:to-pink-500 text-white font-bold py-5 px-8 rounded-2xl transition-all flex justify-center items-center shadow-lg transform hover:-translate-y-1 disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none text-lg"
          >
            {loading ? (
              <>
                <Loader2 className="animate-spin mr-3" /> De magie werkt...
              </>
            ) : (
              'Genereer Mijn Reisplan ✨'
            )}
          </button>
        </div>
      </div>

      <div className="space-y-8">
        {plan.map((day) => (
          <div key={day.day} className="bg-white/80 backdrop-blur rounded-3xl shadow-xl shadow-blue-500/5 overflow-hidden border border-white/60 animate-fade-in group hover:bg-white transition-colors">
            <div className="bg-gradient-to-r from-orange-50 to-pink-50 px-8 py-5 border-b border-orange-100/50 flex items-center">
              <div className="bg-white p-2 rounded-xl shadow-sm mr-4 text-orange-500">
                <Calendar size={24} />
              </div>
              <h3 className="text-2xl font-extrabold text-gray-800">Dag {day.day}</h3>
            </div>
            <div className="p-8">
                {/* Timeline visual line */}
              <div className="relative border-l-2 border-dashed border-gray-200 ml-3 space-y-10">
                {day.activities.map((act, idx) => (
                  <div key={idx} className="relative pl-10">
                     {/* Timeline Dot */}
                    <div className="absolute -left-[9px] top-1 bg-orange-100 border-4 border-white h-5 w-5 rounded-full shadow-sm"></div>
                    
                    <div className="flex flex-col sm:flex-row sm:items-start gap-4 p-4 rounded-2xl hover:bg-gray-50 transition-colors -mt-4">
                        <div className="flex-shrink-0">
                             <div className="text-xs font-bold text-orange-600 bg-orange-50 py-1.5 px-3 rounded-lg border border-orange-100 flex items-center w-fit">
                                <Clock size={12} className="mr-1.5" />
                                {act.time}
                            </div>
                        </div>
                        <div>
                            <h4 className="text-lg font-bold text-gray-900 leading-tight">{act.activity}</h4>
                            <p className="text-gray-500 mt-2 text-sm leading-relaxed">{act.description}</p>
                            {act.location && (
                                <div className="mt-3 inline-flex items-center text-xs font-semibold text-blue-600 bg-blue-50 px-3 py-1.5 rounded-full">
                                <MapPin size={12} className="mr-1" />
                                {act.location}
                                </div>
                            )}
                        </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
        {plan.length === 0 && !loading && (
          <div className="text-center py-20 bg-white/50 rounded-[2rem] border-2 border-dashed border-gray-200/60 backdrop-blur-sm">
            <div className="bg-orange-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Wand2 size={40} className="text-orange-400" />
            </div>
            <p className="text-xl font-medium text-gray-500">Vul hierboven je wensen in.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TravelPlanner;