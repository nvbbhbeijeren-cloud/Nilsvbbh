import React from 'react';
import { ViewState } from '../types';
import { Map, Compass, Star, Crown } from 'lucide-react';

interface Props {
  currentView: ViewState;
  setView: (view: ViewState) => void;
  isPremium: boolean;
}

const Navigation: React.FC<Props> = ({ currentView, setView, isPremium }) => {
  const navItems = [
    { view: ViewState.HOME, label: 'Start', icon: <Compass size={20} /> },
    { view: ViewState.MAP, label: 'Ontdek', icon: <Map size={20} /> },
    { view: ViewState.PLANNER, label: 'Planner', icon: <Star size={20} /> },
    { view: ViewState.PREMIUM, label: 'Premium', icon: <Crown size={20} className={isPremium ? "text-yellow-500 fill-current" : "text-gray-400"} /> },
  ];

  return (
    <nav className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50 shadow-sm transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center cursor-pointer group" onClick={() => setView(ViewState.HOME)}>
             <div className="bg-gradient-to-br from-orange-400 to-pink-500 p-2 rounded-xl mr-3 shadow-md group-hover:rotate-6 transition-transform">
                <Compass className="text-white" size={24} />
             </div>
            <span className="text-2xl font-black bg-clip-text text-transparent bg-gradient-to-r from-orange-500 to-pink-600 tracking-tight">
              Valencia<span className="text-gray-800">Ontdekker</span>
            </span>
          </div>
          <div className="flex space-x-2 sm:space-x-3 items-center">
            {navItems.map((item) => (
              <button
                key={item.view}
                onClick={() => setView(item.view)}
                className={`flex items-center px-4 py-2.5 rounded-full text-sm font-bold transition-all duration-300 transform ${
                  currentView === item.view
                    ? 'bg-gradient-to-r from-orange-100 to-yellow-100 text-orange-600 shadow-sm scale-105 ring-1 ring-orange-200'
                    : 'text-gray-600 hover:bg-white hover:text-orange-500 hover:shadow-md'
                }`}
              >
                <span className={`mr-2 ${currentView === item.view ? 'animate-pulse' : ''}`}>{item.icon}</span>
                <span className="hidden sm:inline">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;