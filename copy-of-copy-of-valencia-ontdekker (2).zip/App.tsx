import React, { useState } from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import TravelPlanner from './components/TravelPlanner';
import InteractiveMap from './components/InteractiveMap';
import PremiumFeatures from './components/PremiumFeatures';
import Chatbot from './components/Chatbot';
import { ViewState } from './types';
import { Crown, Check } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.HOME);
  const [isPremium, setIsPremium] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const togglePremium = () => {
    setIsPremium(!isPremium);
    setShowUpgradeModal(false);
  };

  const renderView = () => {
    switch (currentView) {
      case ViewState.HOME:
        return <Hero setView={setCurrentView} />;
      case ViewState.PLANNER:
        return <TravelPlanner />;
      case ViewState.MAP:
        return <InteractiveMap isPremium={isPremium} />;
      case ViewState.PREMIUM:
        return <PremiumFeatures isPremium={isPremium} triggerUpgrade={() => setShowUpgradeModal(true)} />;
      default:
        return <Hero setView={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-pink-50 font-sans text-gray-900 selection:bg-orange-200 selection:text-orange-900">
      <Navigation currentView={currentView} setView={setCurrentView} isPremium={isPremium} />
      
      <main className="relative z-0">
        {renderView()}
      </main>

      <Chatbot />

      {/* Floating Action Button for easy upgrade toggle (Demo purposes) */}
      <div className="fixed bottom-6 right-6 z-40">
        <button 
          onClick={() => setShowUpgradeModal(true)}
          className={`flex items-center space-x-2 px-6 py-4 rounded-full shadow-xl shadow-orange-500/20 transition-all duration-300 transform hover:scale-105 hover:-translate-y-1 ${isPremium ? 'bg-gray-800 text-white' : 'bg-gradient-to-r from-orange-500 to-pink-500 text-white border-2 border-white/20'}`}
        >
          <Crown size={24} className={isPremium ? "text-yellow-400" : "text-white"} />
          <span className="font-bold text-lg">{isPremium ? 'Jij bent Premium' : 'Upgrade naar Premium'}</span>
        </button>
      </div>

      {/* Footer */}
      <footer className="bg-[#0f172a] text-white py-16 mt-auto relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-500"></div>
        <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10"></div>
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-orange-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-12 relative z-10">
          <div>
            <h3 className="text-3xl font-extrabold mb-6 tracking-tight">Valencia<span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">Ontdekker</span></h3>
            <p className="text-blue-200 text-sm leading-relaxed max-w-xs">
              Het ultieme platform om Valencia te ontdekken als een local. Gemaakt voor zonliefhebbers, avonturiers en levensgenieters.
            </p>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-6 text-orange-400">Navigatie</h4>
            <ul className="space-y-3 text-blue-200 text-sm">
              <li className="hover:text-white hover:translate-x-1 transition-transform cursor-pointer flex items-center" onClick={() => setCurrentView(ViewState.HOME)}>Home</li>
              <li className="hover:text-white hover:translate-x-1 transition-transform cursor-pointer flex items-center" onClick={() => setCurrentView(ViewState.MAP)}>Hotspots</li>
              <li className="hover:text-white hover:translate-x-1 transition-transform cursor-pointer flex items-center" onClick={() => setCurrentView(ViewState.PLANNER)}>Reisplanner</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-6 text-orange-400">Vamos!</h4>
            <p className="text-blue-200 text-sm mb-4">
              Heb je vragen of wil je partner worden?
            </p>
            <a href="mailto:info@valenciaontdekker.es" className="inline-block bg-white/10 hover:bg-white/20 px-6 py-2 rounded-full text-white transition-colors border border-white/10">
              info@valenciaontdekker.es
            </a>
          </div>
        </div>
      </footer>

      {/* Upgrade Modal */}
      {showUpgradeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-indigo-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-md w-full p-8 relative animate-fade-in shadow-2xl border-4 border-orange-100">
            <button 
              onClick={() => setShowUpgradeModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-orange-500 transition-colors bg-gray-100 hover:bg-orange-50 rounded-full p-2"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            
            <div className="text-center mb-8 mt-2">
              <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-5 text-white shadow-lg shadow-orange-200 ring-4 ring-orange-50">
                <Crown size={36} />
              </div>
              <h2 className="text-3xl font-extrabold text-gray-900">Word Valencia <span className="text-orange-500">Insider</span></h2>
              <p className="text-gray-500 mt-3 text-lg">Ontgrendel de volledige ervaring.</p>
            </div>

            <div className="space-y-4 mb-8 bg-orange-50/50 p-6 rounded-2xl border border-orange-100">
              <div className="flex items-center text-gray-700">
                <div className="bg-green-100 p-1 rounded-full mr-3"><Check className="text-green-600" size={16} /></div>
                <span className="font-medium">Exclusieve kortingen bij 50+ partners</span>
              </div>
              <div className="flex items-center text-gray-700">
                <div className="bg-green-100 p-1 rounded-full mr-3"><Check className="text-green-600" size={16} /></div>
                <span className="font-medium">Audio tours die starten op locatie</span>
              </div>
              <div className="flex items-center text-gray-700">
                <div className="bg-green-100 p-1 rounded-full mr-3"><Check className="text-green-600" size={16} /></div>
                <span className="font-medium">Dagelijkse social quiz games</span>
              </div>
            </div>

            <button
              onClick={togglePremium}
              className="w-full py-4 rounded-2xl font-bold text-xl text-white bg-gradient-to-r from-orange-400 to-pink-600 hover:from-orange-500 hover:to-pink-700 transition-all shadow-lg shadow-orange-500/30 transform hover:scale-[1.02]"
            >
              {isPremium ? 'Premium Annuleren (Demo)' : 'Start Nu Premium'}
            </button>
            <p className="text-center text-xs text-gray-400 mt-4 font-medium">Slechts €4,99/maand. Op elk moment opzegbaar.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;