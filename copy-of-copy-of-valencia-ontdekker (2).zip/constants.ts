import { Place } from "./types";

export const PLACES: Place[] = [
  // --- Restaurants & Bars ---
  {
    id: '1',
    name: 'La Pepica',
    type: 'restaurant',
    description: 'Iconisch restaurant aan het strand, beroemd om zijn paella. Ernest Hemingway at hier!',
    address: 'Passeig de Neptú, 6, Valencia',
    isPartner: true,
    discount: '10% korting op de rekening',
    coordinates: { lat: 39.4654, lng: -0.3236 },
    imageUrl: 'https://images.unsplash.com/photo-1515443961218-a51367888e4b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '4',
    name: 'Horchatería Santa Catalina',
    type: 'restaurant',
    description: 'De oudste plek voor een traditionele Horchata met Fartons in het centrum.',
    address: 'Plaça de Santa Caterina, 6',
    isPartner: true,
    discount: 'Gratis Farton bij elke Horchata',
    coordinates: { lat: 39.4745, lng: -0.3764 },
    imageUrl: 'https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '5',
    name: 'Agua de Valencia Bar',
    type: 'restaurant',
    description: 'Gezellige bar in El Carmen gespecialiseerd in de beroemde cocktail.',
    address: 'Carrer de Cavallers, 12',
    isPartner: true,
    discount: '2e cocktail halve prijs',
    coordinates: { lat: 39.4764, lng: -0.3776 },
    imageUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '7',
    name: 'Casa Carmela',
    type: 'restaurant',
    description: 'Authentieke houtoven paella, favoriet bij de locals sinds 1922.',
    address: 'Carrer d\'Isabel de Villena, 155',
    isPartner: false,
    coordinates: { lat: 39.4817, lng: -0.3229 },
    imageUrl: 'https://images.unsplash.com/photo-1626804475297-411dbe66f823?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '8',
    name: 'Ricard Camarena Restaurant',
    type: 'restaurant',
    description: 'Michelin-ster dineren in een voormalige fabriek. Unieke gastronomie.',
    address: 'Av. de Burjassot, 54',
    isPartner: false,
    coordinates: { lat: 39.4883, lng: -0.3892 },
    imageUrl: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '9',
    name: 'Dulce de Leche Boutique',
    type: 'restaurant',
    description: 'Hip café in Ruzafa met de lekkerste taarten en brunch.',
    address: 'Carrer del Pintor Gisbert, 2',
    isPartner: true,
    discount: 'Gratis koffie bij ontbijtmenu',
    coordinates: { lat: 39.4607, lng: -0.3725 },
    imageUrl: 'https://images.unsplash.com/photo-1579306194872-64d3b7bac4c2?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '10',
    name: 'Central Bar',
    type: 'restaurant',
    description: 'Tapas eten midden in Mercado Central bij de bar van Ricard Camarena.',
    address: 'Mercado Central, Valencia',
    isPartner: false,
    coordinates: { lat: 39.4740, lng: -0.3795 },
    imageUrl: 'https://images.unsplash.com/photo-1511690656952-34342d5c2899?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '11',
    name: 'San Tommaso',
    type: 'restaurant',
    description: 'Sfeervol Italiaans restaurant in het hart van de oude stad.',
    address: 'Carrer de la Corretgeria, 39',
    isPartner: true,
    discount: 'Gratis dessert bij hoofdgerecht',
    coordinates: { lat: 39.4752, lng: -0.3770 },
    imageUrl: 'https://images.unsplash.com/photo-1498579150354-977475b7ea0b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '12',
    name: 'Voltereta Bienvenido a Bali',
    type: 'restaurant',
    description: 'Waan je in Indonesië in dit spectaculair ingerichte restaurant.',
    address: 'Gran Via del Marqués del Túria, 59',
    isPartner: false,
    coordinates: { lat: 39.4678, lng: -0.3667 },
    imageUrl: 'https://images.unsplash.com/photo-1596178060810-726447eb108e?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '13',
    name: 'La Mas Bonita',
    type: 'restaurant',
    description: 'Prachtige strandtent in Patacona met heerlijke taarten en sfeer.',
    address: 'Passeig Marítim de la Patacona, 11',
    isPartner: true,
    discount: '10% korting op takeaway',
    coordinates: { lat: 39.4921, lng: -0.3204 },
    imageUrl: 'https://images.unsplash.com/photo-1520623251416-0925e019777f?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '14',
    name: 'Restaurante Navarro',
    type: 'restaurant',
    description: 'Klassieke Valenciaanse keuken in het centrum, bekend om paella met eend.',
    address: 'Carrer de l\'Arquebisbe Mayoral, 5',
    isPartner: false,
    coordinates: { lat: 39.4705, lng: -0.3775 },
    imageUrl: 'https://images.unsplash.com/photo-1563854727142-3f8d3132e4d2?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '15',
    name: 'El Palmar',
    type: 'restaurant',
    description: 'Dorpje midden in de rijstvelden van Albufera. Dé plek voor paella.',
    address: 'El Palmar, Valencia',
    isPartner: true,
    discount: 'Gratis boottocht bij lunch',
    coordinates: { lat: 39.3142, lng: -0.3167 },
    imageUrl: 'https://images.unsplash.com/photo-1621252061214-38bc86377755?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '16',
    name: 'Horchatería Daniel',
    type: 'restaurant',
    description: 'Legendarische horchatería in Alboraya, de bakermat van het drankje.',
    address: 'Av. de l\'Orxata, 41',
    isPartner: false,
    coordinates: { lat: 39.5015, lng: -0.3542 },
    imageUrl: 'https://images.unsplash.com/photo-1616031026046-6a7597143928?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '17',
    name: 'Tinto Fino Ultramarino',
    type: 'restaurant',
    description: 'Gezellige tapasbar met een geweldige wijnselectie.',
    address: 'Carrer de la Corretgeria, 38',
    isPartner: true,
    discount: 'Gratis glas wijn bij tapasplank',
    coordinates: { lat: 39.4751, lng: -0.3771 },
    imageUrl: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '18',
    name: 'Espai Seda',
    type: 'restaurant',
    description: 'Heerlijk dineren op een verborgen terras bij het zijdemuseum.',
    address: 'Carrer de l\'Hospital, 7',
    isPartner: false,
    coordinates: { lat: 39.4716, lng: -0.3799 },
    imageUrl: 'https://images.unsplash.com/photo-1560624052-449f5ddf0c31?auto=format&fit=crop&w=800&q=80'
  },

  // --- Culture ---
  {
    id: '2',
    name: 'Ciudad de las Artes y las Ciencias',
    type: 'culture',
    description: 'Het futuristische symbool van Valencia. Een must-see architectonisch wonder.',
    address: 'Av. del Professor López Piñero, 7',
    isPartner: false,
    coordinates: { lat: 39.4549, lng: -0.3508 },
    imageUrl: 'https://images.unsplash.com/photo-1542114707-1e8a38184f47?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '19',
    name: 'La Lonja de la Seda',
    type: 'culture',
    description: 'UNESCO Werelderfgoed. De oude zijdebeurs, een gotisch meesterwerk.',
    address: 'Carrer de la Llotja, 2',
    isPartner: false,
    coordinates: { lat: 39.4744, lng: -0.3784 },
    imageUrl: 'https://images.unsplash.com/photo-1563294628-8d022204c455?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '20',
    name: 'Catedral de Valencia',
    type: 'culture',
    description: 'De thuisbasis van de Heilige Graal. Beklim de Miguelete toren voor uitzicht.',
    address: 'Plaça de l\'Almoina, s/n',
    isPartner: false,
    coordinates: { lat: 39.4753, lng: -0.3755 },
    imageUrl: 'https://images.unsplash.com/photo-1588607106069-459d248b11a1?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '21',
    name: 'Torres de Serranos',
    type: 'culture',
    description: 'Een van de twee overgebleven stadspoorten van de oude stadsmuur.',
    address: 'Plaça dels Furs, s/n',
    isPartner: true,
    discount: 'Gratis audiotour via app',
    coordinates: { lat: 39.4791, lng: -0.3760 },
    imageUrl: 'https://images.unsplash.com/photo-1596541663957-3075670868a6?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '22',
    name: 'Plaza de la Virgen',
    type: 'culture',
    description: 'Het historische hart van de stad met de beroemde Turia fontein.',
    address: 'Plaça de la Verge',
    isPartner: false,
    coordinates: { lat: 39.4764, lng: -0.3753 },
    imageUrl: 'https://images.unsplash.com/photo-1605649988225-b467e45e982d?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '23',
    name: 'Palacio del Marqués de Dos Aguas',
    type: 'culture',
    description: 'Nationaal Keramiekmuseum met een verbluffende albasten barokke gevel.',
    address: 'Carrer del Poeta Querol, 2',
    isPartner: false,
    coordinates: { lat: 39.4725, lng: -0.3745 },
    imageUrl: 'https://images.unsplash.com/photo-1576772782484-8276d49554a9?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '24',
    name: 'Estació del Nord',
    type: 'culture',
    description: 'Prachtig modernistisch treinstation met veel mozaïekwerk.',
    address: 'Carrer d\'Alacant, 25',
    isPartner: false,
    coordinates: { lat: 39.4670, lng: -0.3773 },
    imageUrl: 'https://images.unsplash.com/photo-1596131398701-d8050949d214?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '25',
    name: 'Mercado de Colón',
    type: 'culture',
    description: 'Chique markthal omgebouwd tot een gastro-ruimte met cafés en restaurants.',
    address: 'Carrer de Jorge Juan, 19',
    isPartner: true,
    discount: '10% korting bij geselecteerde kraampjes',
    coordinates: { lat: 39.4697, lng: -0.3695 },
    imageUrl: 'https://images.unsplash.com/photo-1582298583416-015e4a504d6e?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '26',
    name: 'IVAM',
    type: 'culture',
    description: 'Institut Valencià d\'Art Modern. Hedendaagse kunst in een strak gebouw.',
    address: 'Carrer de Guillem de Castro, 118',
    isPartner: false,
    coordinates: { lat: 39.4806, lng: -0.3828 },
    imageUrl: 'https://images.unsplash.com/photo-1545989253-02cc26577f88?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '27',
    name: 'Museo de Bellas Artes',
    type: 'culture',
    description: 'Een van de belangrijkste kunstmusea van Spanje, met werken van Goya en Velázquez.',
    address: 'Carrer de Sant Pius V, 9',
    isPartner: false,
    coordinates: { lat: 39.4795, lng: -0.3703 },
    imageUrl: 'https://images.unsplash.com/photo-1583095368307-28689531649c?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '28',
    name: 'San Nicolás Church',
    type: 'culture',
    description: 'De "Sixtijnse Kapel" van Valencia. Adembenemende fresco\'s.',
    address: 'Carrer dels Cavallers, 35',
    isPartner: true,
    discount: '€2 korting op entree',
    coordinates: { lat: 39.4761, lng: -0.3787 },
    imageUrl: 'https://images.unsplash.com/photo-1548625361-1960144c53c0?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '29',
    name: 'Torres de Quart',
    type: 'culture',
    description: 'De westelijke stadspoort, die nog steeds de littekens van kanonskogels draagt.',
    address: 'Plaça de Santa Úrsula',
    isPartner: false,
    coordinates: { lat: 39.4757, lng: -0.3840 },
    imageUrl: 'https://images.unsplash.com/photo-1620215772652-9447e112cb9b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '30',
    name: 'Museo Fallero',
    type: 'culture',
    description: 'Museum waar de geredde "Ninots" van het Las Fallas festival worden tentoongesteld.',
    address: 'Plaça de Montolivet, 4',
    isPartner: false,
    coordinates: { lat: 39.4611, lng: -0.3582 },
    imageUrl: 'https://images.unsplash.com/photo-1616429215886-c4d375354964?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '31',
    name: 'Centre del Carme',
    type: 'culture',
    description: 'Oud klooster omgebouwd tot cultureel centrum met wisselende exposities.',
    address: 'Carrer del Museu, 2',
    isPartner: false,
    coordinates: { lat: 39.4800, lng: -0.3790 },
    imageUrl: 'https://images.unsplash.com/photo-1605364850024-5d9c792120e2?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '32',
    name: 'Palau de la Música',
    type: 'culture',
    description: 'Concertgebouw in de Turia tuinen met prachtige glazen gevel en palmbomen binnen.',
    address: 'Passeig de l\'Albereda, 30',
    isPartner: false,
    coordinates: { lat: 39.4674, lng: -0.3614 },
    imageUrl: 'https://images.unsplash.com/photo-1514533450685-4493e01d1fdc?auto=format&fit=crop&w=800&q=80'
  },

  // --- Activities ---
  {
    id: '3',
    name: 'Mercado Central',
    type: 'activity',
    description: 'Een van de oudste nog draaiende markten van Europa. Proef de lokale sfeer.',
    address: 'Plaça de la Ciutat de Bruges',
    isPartner: false,
    coordinates: { lat: 39.4741, lng: -0.3794 },
    imageUrl: 'https://images.unsplash.com/photo-1533920145262-327c56a6eb2a?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '6',
    name: 'Turia Park Fietstour',
    type: 'activity',
    description: 'Huur een fiets en ontdek de groene long van de stad in de drooggelegde rivierbedding.',
    address: 'Jardín del Turia',
    isPartner: true,
    discount: '15% korting op fietsverhuur',
    coordinates: { lat: 39.4690, lng: -0.3600 },
    imageUrl: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '33',
    name: 'Oceanogràfic',
    type: 'activity',
    description: 'Het grootste aquarium van Europa. Loop door tunnels omringd door haaien.',
    address: 'Carrer d\'Eduardo Primo Yúfera, 1B',
    isPartner: true,
    discount: 'Fast-track toegang',
    coordinates: { lat: 39.4528, lng: -0.3484 },
    imageUrl: 'https://images.unsplash.com/photo-1582991880461-8b438dbdb031?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '34',
    name: 'Bioparc Valencia',
    type: 'activity',
    description: 'Een innovatieve dierentuin zonder hekken, die de Afrikaanse savanne nabootst.',
    address: 'Av. Pío Baroja, 3',
    isPartner: true,
    discount: '10% korting op familietickets',
    coordinates: { lat: 39.4784, lng: -0.4077 },
    imageUrl: 'https://images.unsplash.com/photo-1575550959106-5a7defe28b56?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '35',
    name: 'Albufera Boottocht',
    type: 'activity',
    description: 'Vaar tijdens zonsondergang over het grootste meer van Spanje.',
    address: 'Embarcadero de la Albufera',
    isPartner: true,
    discount: '2e persoon gratis bij zonsondergang',
    coordinates: { lat: 39.3333, lng: -0.3333 },
    imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '36',
    name: 'Mestalla Stadion Tour',
    type: 'activity',
    description: 'Bezoek het historische stadion van Valencia CF, een van de oudste in Spanje.',
    address: 'Av. de Suècia, s/n',
    isPartner: false,
    coordinates: { lat: 39.4746, lng: -0.3582 },
    imageUrl: 'https://images.unsplash.com/photo-1577223625816-7546f13df25d?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '37',
    name: 'Playa de la Malvarrosa',
    type: 'activity',
    description: 'Het stadsstrand van Valencia. Breed zandstrand met een gezellige boulevard.',
    address: 'Passeig de Neptú',
    isPartner: false,
    coordinates: { lat: 39.4675, lng: -0.3230 },
    imageUrl: 'https://images.unsplash.com/photo-1588785662770-5e527d49864b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '38',
    name: 'Jardín de Monforte',
    type: 'activity',
    description: 'Een romantische, neoklassieke tuin vol standbeelden en fonteinen.',
    address: 'Carrer de Montfort',
    isPartner: false,
    coordinates: { lat: 39.4786, lng: -0.3639 },
    imageUrl: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '39',
    name: 'Gulliver Park',
    type: 'activity',
    description: 'Gigantische speeltuin in de vorm van Gulliver. Geweldig voor kinderen (en volwassenen).',
    address: 'Jardín del Turia',
    isPartner: false,
    coordinates: { lat: 39.4627, lng: -0.3592 },
    imageUrl: 'https://images.unsplash.com/photo-1620509652225-4c0744e3395b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '40',
    name: 'Hemisfèric',
    type: 'activity',
    description: 'IMAX bioscoop en planetarium in de vorm van een gigantisch oog.',
    address: 'Av. del Professor López Piñero, 3',
    isPartner: false,
    coordinates: { lat: 39.4557, lng: -0.3541 },
    imageUrl: 'https://images.unsplash.com/photo-1516962215378-7fa2e137ae16?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '41',
    name: 'Cabanyal Wijkwandeling',
    type: 'activity',
    description: 'Verken de oude visserswijk met zijn kleurrijke betegelde huizen.',
    address: 'El Cabanyal',
    isPartner: true,
    discount: 'Gratis digitale wandelgids',
    coordinates: { lat: 39.4699, lng: -0.3289 },
    imageUrl: 'https://images.unsplash.com/photo-1512413346738-9cb579bc19c3?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '42',
    name: 'Jardín Botánico',
    type: 'activity',
    description: 'Botanische tuin van de universiteit, een oase van rust vol zeldzame planten.',
    address: 'Carrer de Quart, 80',
    isPartner: false,
    coordinates: { lat: 39.4770, lng: -0.3860 },
    imageUrl: 'https://images.unsplash.com/photo-1496568257322-1981d3bc8d8c?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '43',
    name: 'Catamaran Cruise',
    type: 'activity',
    description: 'Zeiltocht vanuit de haven, perfect om af te koelen op zee.',
    address: 'Marina de Valencia',
    isPartner: true,
    discount: '10% korting op ochtendvaarten',
    coordinates: { lat: 39.4616, lng: -0.3225 },
    imageUrl: 'https://images.unsplash.com/photo-1566418855470-3636599292e9?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '44',
    name: 'Veles e Vents',
    type: 'activity',
    description: 'Iconisch gebouw in de haven, hotspot voor events en uitzicht.',
    address: 'Marina de Valencia',
    isPartner: false,
    coordinates: { lat: 39.4608, lng: -0.3232 },
    imageUrl: 'https://images.unsplash.com/photo-1619623661271-92cb716f9f6e?auto=format&fit=crop&w=800&q=80'
  },

  // --- Shops ---
  {
    id: '45',
    name: 'Calle Colón',
    type: 'shop',
    description: 'De belangrijkste winkelstraat van Valencia met alle grote merken.',
    address: 'Carrer de Colón',
    isPartner: false,
    coordinates: { lat: 39.4688, lng: -0.3730 },
    imageUrl: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '46',
    name: 'Mercado de Ruzafa',
    type: 'shop',
    description: 'Kleurrijke buurtmarkt in de trendy wijk Ruzafa. Minder toeristisch dan Central.',
    address: 'Plaça del Baró de Corts',
    isPartner: false,
    coordinates: { lat: 39.4633, lng: -0.3755 },
    imageUrl: 'https://images.unsplash.com/photo-1488459716781-31db52582fe9?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '47',
    name: 'Plaza Redonda',
    type: 'shop',
    description: 'Uniek rond plein vol met kleine winkeltjes voor handwerk en souvenirs.',
    address: 'Plaça Redona',
    isPartner: true,
    discount: '5% korting bij keramiekwinkel',
    coordinates: { lat: 39.4737, lng: -0.3780 },
    imageUrl: 'https://images.unsplash.com/photo-1519789112957-c3a1b02534cb?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '48',
    name: 'Cestos y Mimbres',
    type: 'shop',
    description: 'Traditionele winkel gespecialiseerd in rieten manden en tassen.',
    address: 'Carrer del Músic Peydró, 52',
    isPartner: true,
    discount: '10% korting op handgemaakte tassen',
    coordinates: { lat: 39.4735, lng: -0.3790 },
    imageUrl: 'https://images.unsplash.com/photo-1599692482352-7e7215274d44?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '49',
    name: 'Ale-Hop Flagship',
    type: 'shop',
    description: 'De bekende Spaanse cadeauwinkel, met de koe voor de deur.',
    address: 'Plaza del Ayuntamiento',
    isPartner: false,
    coordinates: { lat: 39.4700, lng: -0.3760 },
    imageUrl: 'https://images.unsplash.com/photo-1531265726475-52ad60219627?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '50',
    name: 'Simple',
    type: 'shop',
    description: 'Winkel met prachtige, lokaal gemaakte Spaanse producten en design.',
    address: 'Carrer del Palau, 5',
    isPartner: true,
    discount: 'Gratis ansichtkaart bij aankoop',
    coordinates: { lat: 39.4755, lng: -0.3765 },
    imageUrl: 'https://images.unsplash.com/photo-1550928431-ee0ec6db30d3?auto=format&fit=crop&w=800&q=80'
  }
];