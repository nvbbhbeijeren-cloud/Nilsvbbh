import { GoogleGenAI, Type, Chat, Modality } from "@google/genai";
import { DayPlan, QuizQuestion } from "../types";
import { PLACES } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Simple in-memory cache to store generated audio (base64 strings)
const audioCache = new Map<string, string>();

// Construct the context string from the PLACES constant
const SITE_CONTEXT = `
Je bent de virtuele gids en assistent van het platform "Valencia Ontdekker".
Jouw doel is om gebruikers te helpen de stad te ontdekken en vragen te beantwoorden over de website en de locaties.

INFORMATIE OVER HET PLATFORM:
- Home: Algemene introductie.
- Ontdek (Kaart): Een interactieve kaart en lijst met 50 hotspots.
- Planner: Een AI-gedreven reisplanner die dagplanningen maakt.
- Premium: Betaald abonnement (€4,99/mnd) voor Audio Tours, Dagelijkse Quizzen en Exclusieve Kortingen.

DATABASE VAN LOCATIES (Hotspots):
${JSON.stringify(PLACES.map(p => ({
  name: p.name,
  type: p.type,
  description: p.description,
  partner: p.isPartner,
  discount: p.isPartner ? p.discount : "Geen korting",
  address: p.address
})))}

RICHTLIJNEN VOOR JE ANTWOORDEN:
1. Antwoord altijd in het Nederlands.
2. Wees enthousiast, vriendelijk en behulpzaam.
3. Houd antwoorden beknopt (max 3-4 zinnen) tenzij de gebruiker om details vraagt.
4. Als iemand vraagt naar eten, activiteiten of cultuur, raad specifiek locaties uit de database aan.
5. Als je een 'Partner' locatie aanraadt, vermeld dan ALTIJD de exclusieve premium korting (bijv: "Als partner krijg je hier 10% korting!").
6. Verwijs voor Audio Tours en Quizzen naar het Premium gedeelte.
`;

export const createChatSession = (): Chat => {
  return ai.chats.create({
    model: "gemini-2.5-flash",
    config: {
      systemInstruction: SITE_CONTEXT,
    },
  });
};

export const generateTravelPlan = async (days: number, interests: string): Promise<DayPlan[]> => {
  try {
    const prompt = `
      Maak een reisplan voor Valencia, Spanje voor ${days} dagen.
      De gebruiker is geïnteresseerd in: ${interests}.
      Zorg voor een mix van cultuur, eten (paella, tapas) en ontspanning.
      Integreer specifiek lokale 'partner' restaurants waar mogelijk.
      Geef het antwoord in het Nederlands.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              day: { type: Type.INTEGER },
              activities: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    time: { type: Type.STRING },
                    activity: { type: Type.STRING },
                    description: { type: Type.STRING },
                    location: { type: Type.STRING },
                  }
                }
              }
            }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as DayPlan[];
    }
    return [];
  } catch (error) {
    console.error("Error generating plan:", error);
    return [];
  }
};

export const generateQuiz = async (): Promise<QuizQuestion[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: "Genereer 3 leuke, interessante quizvragen over Valencia (geschiedenis, cultuur, eten).",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              correctAnswer: { type: Type.INTEGER, description: "Index of the correct answer (0-3)" },
              explanation: { type: Type.STRING }
            }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as QuizQuestion[];
    }
    return [];
  } catch (error) {
    console.error("Error generating quiz:", error);
    return [];
  }
};

export const generateAudioGuide = async (locationName: string): Promise<string | null> => {
  // 1. Check if we already have this audio in cache
  if (audioCache.has(locationName)) {
    console.log(`Using cached audio for ${locationName}`);
    return audioCache.get(locationName) || null;
  }

  try {
    let prompt = "";

    // Specific script for Plaza de la Virgen provided by the user
    if (locationName === 'Plaza de la Virgen') {
      const specificScript = `Welkom op Plaza de la Virgen, een van de gezelligste en mooiste pleinen van Valencia. Je staat hier op een plek waar de stad al meer dan 2.000 jaar leeft, bruist en samenkomt.

Kijk eerst even naar de grote fontein in het midden. De man die je ziet is een voorstelling van de rivier de Turia. De vrouwen eromheen stellen de kanalen voor die het water door de stad verspreiden. Het is eigenlijk een groot eerbetoon aan hoe belangrijk water altijd is geweest voor Valencia.

Als je naar de grote kerk aan de rand van het plein kijkt, zie je de Puerta de los Apóstoles, een prachtige gotische ingang van de kathedraal. Hier gebeurt iets heel bijzonders: elke donderdag komt het Tribunal de las Aguas bij elkaar. Dat is het oudste rechtshof van Europa. Ze beslissen hier al meer dan duizend jaar over waterproblemen tussen boeren. Geen papier, geen computers — gewoon stoelen, mensen en praten. Heel simpel, heel bijzonder.

Aan de andere kant van het plein staat de Basilica de la Virgen de los Desamparados. Dit is een kerk die voor veel inwoners heel belangrijk is. Hij is gewijd aan de beschermheilige van de stad. Let op de mooie blauwe koepel, die zie je overal terug in Valencia.

Plaza de la Virgen is de plek waar het echte Valencia samenkomt. Overdag zie je hier mensen koffie drinken, foto’s maken of even uitrusten. ’s Avonds wordt het plein extra sfeervol met warme verlichting en muziek. Het is een plek waar je rustig even kunt zitten en de sfeer voelt — het is alsof alles hier net een beetje magischer klinkt en lijkt.

Als je rondkijkt, zie je smalle straatjes die je de oude binnenstad in leiden, vol leuke restaurantjes en barretjes. Dit plein is eigenlijk het hart van Valencia. Iedereen komt hier wel eens terug, of je nu toerist bent of hier woont.

Neem nog even een moment om te genieten, luister naar het water, kijk naar de gebouwen en voel hoe oud en levendig deze plek is.

Dit is Plaza de la Virgen — en vandaag ben jij er deel van.`;

      prompt = `
      Lees de volgende tekst voor als een charismatische, warme en rustige vrouwelijke gids.
      Spreek de tekst letterlijk uit, verander niets aan de inhoud, maar gebruik een natuurlijk ritme en intonatie.
      Zorg voor een zachte, heldere stem.
      
      TEKST:
      ${specificScript}
      `;
    } else {
      // Dynamic generation for other locations
      prompt = `
      Je bent een charismatische, rustige lokale gids in Valencia (vrouw). Je staat nu fysiek met de bezoeker voor: ${locationName}.
      
      Jouw taak:
      1. Vertel een kort, boeiend verhaal (max 40 seconden spreektijd).
      2. Gebruik spreektaal (natuurlijk, warm, niet monotoon).
      3. Begin met een leuke opening zoals "Kijk eens omhoog..." of "Wist je dat...".
      4. Geef één uniek feitje dat niet in de standaard reisgidsen staat.
      5. Spreek in helder Nederlands met een rustige toon.
      `;
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: prompt,
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Zephyr' }, // Zephyr is consistent, clear, and friendly.
          },
        },
      },
    });

    const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;

    // 2. Save to cache if successful
    if (audioData) {
      audioCache.set(locationName, audioData);
    }

    return audioData;
  } catch (error) {
    console.error("Error generating audio guide:", error);
    return null;
  }
};